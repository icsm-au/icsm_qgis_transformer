# -*- coding: utf-8 -*-
"""
/***************************************************************************
 icsm_ntv2_transformer
                                 A QGIS plugin
 This plugin uses official ICSM grids to transform between Australian coordinate systems.
                              -------------------
        begin                : 2017-01-08
        git sha              : $Format:%H$
        copyright            : (C) 2017 by Alex Leith
        email                : alex@auspatious.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from __future__ import print_function

import os.path
import subprocess
import tempfile
from collections import namedtuple

from gdalconst import GA_ReadOnly
from osgeo import gdal, osr

from icsm_qgis_transformer_dialog import icsm_ntv2_transformerDialog
from PyQt4.QtCore import (SIGNAL, QCoreApplication, QObject, QSettings,
                          QTranslator, qVersion)
from PyQt4.QtGui import QAction, QFileDialog, QIcon
from qgis.core import (QgsCoordinateReferenceSystem, QgsMessageLog,
                       QgsVectorFileWriter, QgsVectorLayer)
from qgis.gui import QgsMessageBar

Transform = namedtuple(
    'Transform',
    ['name', 'source_name', 'target_name', 'source_proj', 'target_proj', 'source_code', 'target_code', 'grid'],
    verbose=True
)


def log(message, error=False):
    log_level = QgsMessageLog.INFO
    if error:
        log_level = QgsMessageLog.CRITICAL
    QgsMessageLog.logMessage(message, 'ICSM NTv2 Transformer', level=log_level)


class icsm_ntv2_transformer:
    """QGIS Plugin Implementation."""
    AGD66GRID = os.path.dirname(__file__) + '/grids/A66_National_13_09_01.gsb'
    AGD84GRID = os.path.dirname(__file__) + '/grids/National_84_02_07_01.gsb'

    # These comments are printed in the dialog that describes the transform to be carried out.
    GRID_COMMENTS = {
        'A66_National_13_09_01.gsb': (
            "NTv2 transformation grid A66_national_13_09_01.gsb [EPSG:1803] provides complete national coverage.\n"
            "See Appendix A of Geocentric Datum of Australia 2020 Technical Manual for grid coverage and description"
        ),
        'National_84_02_07_01.gsb': (
            "NTv2 transformation grid National_84_02_07_01.gsb [EPSG:1804] only has coverage for jurisdictions that adopted AGD84 – QLD, SA and WA.\n"
            "See Appendix A of Geocentric Datum of Australia 2020 Technical Manual for grid coverage and description."
        ),
        'GDA94_GDA2020_conformal_YYYMMDD.gsb': (
            "NTv2 transformation grid GDA94_GDA2020_conformal_YYYMMDD.gsb [EPSG:????] only applies a conformal transformation between the datums.\n"
            "See Section 3.6.1 of Geocentric Datum of Australia 2020 Technical Manual for a description of the grid and when it is appropriate to apply."
        )
    }

    # EPSGs, in code, name, utm
    available_epsgs = {
        '202': {
            "name": "AGD66 AMG",
            "utm": True,
            "proj": '+proj=utm +zone={zone} +south +ellps=aust_SA +units=m +no_defs +nadgrids=' + AGD66GRID + ' +wktext',
            "grid": AGD66GRID,
            "comments": ""
        },
        '203': {
            "name": "AGD84 AMG",
            "utm": True,
            "proj": '+proj=utm +zone={zone} +south +ellps=aust_SA +units=m +no_defs +nadgrids=' + AGD84GRID + ' +wktext',
            "grid": AGD84GRID
        },
        '283': {
            "name": "GDA94 MGA",
            'utm': True,
            "proj": None,
            "grid": None
        },
        '4202': {
            "name": "AGD66 LonLat",
            "utm": False,
            "proj": '+proj=longlat +ellps=aust_SA +no_defs +nadgrids=' + AGD66GRID + ' +wktext',
            "grid": AGD66GRID
        },
        '4203': {
            "name": "AGD84 LonLat",
            "utm": False,
            "proj": '+proj=longlat +ellps=aust_SA +no_defs +nadgrids=' + AGD84GRID + ' +wktext',
            "grid": AGD84GRID
        },
        '4283': {
            "name": "GDA94 LonLat",
            "utm": False,
            "proj": None,
            "grid": None
        }
    }

    # Supported Transforms. FROM_CRS: [name, from, to, zone]
    SUPPORTED_TRANSFORMS = {
        # Transform('name', 'source_name', 'target_name', 'source_proj', 'target_proj', 'grid')
    }
    TRANSFORMS = []

    # Range makes a list from 49 to 56
    available_zones = range(49, 57)

    # transformations - a list of FROM and all available TOs
    transformations = [
        # UTM
        ['202', ['283']],
        ['203', ['283']],
        ['283', ['202', '203']],
        # LonLat
        ['4202', ['4283']],
        ['4203', ['4283']],
        ['4283', ['4202', '4203']]
    ]

    def build_transform(self, in_info, in_crs, zone=False):
        source_name = in_info['name']
        source_proj = in_info['proj']
        source_grid = in_info['grid']
        source_epsg = in_crs[0]
        source_target_epsgs = in_crs[1]
        zone_string = ""
        if zone:
            zone_string = str(zone)

        source_code = '{epsg}{zone}'.format(epsg=source_epsg, zone=zone_string)
        epsg_string = 'EPSG:{}'.format(source_code)
        name_string = "{name} [EPSG:{code}]"

        if zone and source_proj:
            source_proj = source_proj.format(zone=zone)

        target_crs = []
        for target_epsg in source_target_epsgs:
            target_name = self.available_epsgs[target_epsg]['name']
            target_grid = self.available_epsgs[target_epsg]['grid']
            target_code = '{epsg}{zone}'.format(epsg=target_epsg, zone=zone_string)
            name = source_name.split(' ')[0] + ' to ' + target_name.split(' ')[0]
            source = name_string.format(name=source_name, code=source_code)
            target = name_string.format(name=target_name, code=target_code)
            target_proj = self.available_epsgs[target_epsg]['proj']

            if zone and target_proj:
                target_proj = target_proj.format(zone=zone)

            grid = None
            if source_grid:
                grid = source_grid
            elif target_grid:
                grid = target_grid
            grid = os.path.basename(grid)
            grid_text = ""
            if grid:
                grid_text = "using NTv2 grid: '{}'".format(grid)
                comments = self.GRID_COMMENTS.get(grid)
                grid_text += "\n\n" + comments

            target_crs.append(Transform(name, source, target, source_proj, target_proj, int(source_code), int(target_code), grid_text))

        return epsg_string, target_crs

    def update_transform_text(self, text):
        self.dlg.transform_text.setPlainText(text)

    def transform_changed(self):
        self.validate_source_transform()

    def get_dest_crs(self, source_crs):
        this_source_crs = self.SUPPORTED_TRANSFORMS[self.in_file_crs]

        dest_crs = self.CRS_STRINGS[this_source_crs[2]][0]
        zone = this_source_crs[3]

        if zone:
            dest_crs = dest_crs.format(zone=zone)

        return dest_crs

    def get_source_proj_string(self, source_crs):
        this_source_crs = self.SUPPORTED_TRANSFORMS[self.in_file_crs]

        proj_string = self.CRS_STRINGS[this_source_crs[1]][1]
        zone = this_source_crs[3]

        if zone:
            proj_string = proj_string.format(zone=zone)

        return proj_string

    def validate_source_transform(self, in_file_crs=None):
        # Check if there's an in_file
        if not self.in_file and not self.in_file_type:
            self.update_transform_text("Select an input file.")
            return

        if in_file_crs:
            # Set up a new CRS transform environment, as the in_file has changed
            if in_file_crs in self.SUPPORTED_TRANSFORMS:
                log("Selected CRS is supported")
                self.TRANSFORMS = self.SUPPORTED_TRANSFORMS[in_file_crs]
                self.SELECTED_TRANSFORM = self.TRANSFORMS[0]

                self.dlg.out_crs_picker.clear()
                for transform in self.TRANSFORMS:
                    self.dlg.out_crs_picker.addItems([transform.target_name])
            else:
                log("Selected CRS is NOT supported.")
                self.in_file_type = None
                self.update_transform_text("The CRS {} for the selected input file is not supported.".format(in_file_crs))
                return
        else:
            if self.dlg.out_crs_picker.currentIndex() != -1:
                # Change the selected transform
                self.SELECTED_TRANSFORM = self.TRANSFORMS[self.dlg.out_crs_picker.currentIndex()]
            else:
                # Something's gone wrong
                self.update_transform_text("Unable to identify the source file's CRS...")
                return

        self.update_transform_text("Source CRS is {}\nDestination CRS is {}\n\nTransforming from {} {}".format(
            self.SELECTED_TRANSFORM.source_name,
            self.SELECTED_TRANSFORM.target_name,
            self.SELECTED_TRANSFORM.name,
            self.SELECTED_TRANSFORM.grid))

    def update_infile(self):
        log("Updating in file")
        newname = self.dlg.in_file_name.text()

        # Clear out dialogs
        self.in_file_type = None
        self.in_file_crs = None
        self.dlg.out_crs_picker.clear()

        fail = False
        layer = QgsVectorLayer(newname, 'in layer', 'ogr')
        if layer.isValid():
            # We have a vector!
            self.in_file_type = 'VECTOR'
            in_file_crs = layer.crs().authid()
            self.validate_source_transform(in_file_crs)
            self.in_dataset = layer
        else:
            dataset = gdal.Open(newname, GA_ReadOnly)
            if dataset is None:
                fail = True
            else:
                # We have a raster!
                self.in_file_type = 'RASTER'
                prj = dataset.GetProjection()
                crs = QgsCoordinateReferenceSystem(prj)
                log(crs.toProj4())
                in_file_crs = crs.authid()
                self.validate_source_transform(in_file_crs)
                self.in_dataset = dataset
        if fail:
            self.iface.messageBar().pushMessage(
                "Error", "Couldn't read 'in file' {} as vector or raster".format(newname), level=QgsMessageBar.CRITICAL, duration=3)
            self.update_transform_text("Couldn't read 'In file.'")
        else:
            self.dlg.in_file_name.setText(newname)

    def browse_infiles(self):
        log("Browsing in files")
        newname = QFileDialog.getOpenFileName(
            None, "Input File", self.dlg.in_file_name.displayText(), "Any supported filetype (*.*)")
        if newname:
            self.dlg.in_file_name.setText(newname)
        # self.update_infile()

    def browse_outfiles(self):
        newname = QFileDialog.getSaveFileName(
            None, "Output file", self.dlg.out_file_name.displayText(), "Shapefile or TIFF (*.shp, *.tiff)")

        if newname:
            self.dlg.out_file_name.setText(newname)

    def get_epsg(self, layer):
        return layer.crs().authid().split(':')[1]

    def transform_vector(self, out_file):
        log("Transforming")
        layer = self.in_dataset

        source_crs = QgsCoordinateReferenceSystem()
        if self.SELECTED_TRANSFORM.source_proj:
            log("Source from proj")
            log(self.SELECTED_TRANSFORM.source_proj)
            source_crs.createFromProj4(self.SELECTED_TRANSFORM.source_proj)
        else:
            log("Source from id")
            source_crs.createFromId(self.SELECTED_TRANSFORM.source_code)

        log("Setting Source CRS")
        layer.setCrs(source_crs)

        dest_crs = QgsCoordinateReferenceSystem()
        if self.SELECTED_TRANSFORM.target_proj:
            log("Target from proj")
            log(self.SELECTED_TRANSFORM.target_proj)
            dest_crs.createFromProj4(self.SELECTED_TRANSFORM.target_proj)

            # We do an intermediate transform, so that the target gets a proper SRID
            temp_dir = tempfile.mkdtemp()
            temp_outfilename = os.path.join(temp_dir, 'temp_file.shp')
            log(temp_outfilename)
            error = QgsVectorFileWriter.writeAsVectorFormat(layer, temp_outfilename, 'utf-8', dest_crs, 'ESRI Shapefile')
            if error == QgsVectorFileWriter.NoError:
                log("Success on intermediate transform")
                # These overwrite the original target layer destination file.
                layer = QgsVectorLayer(temp_outfilename, 'in layer', 'ogr')
                dest_crs.createFromId(self.SELECTED_TRANSFORM.target_code)
            else:
                log("Error writing vector, code: {}".format(str(error)))
                self.iface.messageBar().pushMessage(
                    "Error", "Transformation failed, please check your configuration.", level=QgsMessageBar.CRITICAL, duration=3)
                return
        else:
            log("Target from id")
            dest_crs.createFromId(self.SELECTED_TRANSFORM.target_code)

        error = QgsVectorFileWriter.writeAsVectorFormat(layer, out_file, 'utf-8', dest_crs, 'ESRI Shapefile')
        if error == QgsVectorFileWriter.NoError:
            log("Success")
            self.iface.messageBar().pushMessage(
                "Success", "Transformation complete.", level=QgsMessageBar.INFO, duration=3)
        else:
            log("Error writing vector, code: {}".format(str(error)))
            self.iface.messageBar().pushMessage(
                "Error", "Transformation failed, please check your configuration.", level=QgsMessageBar.CRITICAL, duration=3)

    def transform_raster(self, out_file):
        src_ds = self.in_dataset

        # Define source CRS
        src_crs = osr.SpatialReference()
        if self.SELECTED_TRANSFORM.source_proj:
            src_crs.ImportFromProj4(self.SELECTED_TRANSFORM.source_proj)
        else:
            src_crs.ImportFromEPSG(self.SELECTED_TRANSFORM.source_code)
        src_wkt = src_crs.ExportToWkt()

        # Define target CRS
        dst_crs = osr.SpatialReference()
        if self.SELECTED_TRANSFORM.target_proj:
            dst_crs.ImportFromProj4(self.SELECTED_TRANSFORM.target_proj)
        else:
            dst_crs.ImportFromEPSG(self.SELECTED_TRANSFORM.target_code)
        dst_wkt = dst_crs.ExportToWkt()

        error_threshold = 0.125
        resampling = gdal.GRA_NearestNeighbour

        # Call AutoCreateWarpedVRT() to fetch default values for target raster dimensions and geotransform
        tmp_ds = gdal.AutoCreateWarpedVRT(
            src_ds,
            src_wkt,
            dst_wkt,
            resampling,
            error_threshold
        )
        # Create the final warped raster
        try:
            if '.tif' not in out_file:
                out_file += '.tiff'
            dst_ds = gdal.GetDriverByName('GTiff').CreateCopy(out_file, tmp_ds)
            dst_ds = None
            self.iface.messageBar().pushMessage(
                "Success", "Transformation complete.", level=QgsMessageBar.INFO, duration=3)
        except Exception as e:
            self.iface.messageBar().pushMessage(
                "Error", "Transformation failed, please check your configuration. Error was: {}".format(e), level=QgsMessageBar.CRITICAL, duration=3)

    def __init__(self, iface):
        self.dialog_initialised = False
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'icsm_ntv2_transformer_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&ICSM NTv2 Transformer')
        self.toolbar = self.iface.addToolBar(u'icsm_ntv2_transformer')
        self.toolbar.setObjectName(u'icsm_ntv2_transformer')

        self.in_file = None
        self.out_file = None

        self.in_dataset = None

        self.in_file_type = None

        for source_crs in self.transformations:
            epsg_info = self.available_epsgs[source_crs[0]]
            if epsg_info['utm']:
                # This is a UTM crs, so process all the codes
                for zone in self.available_zones:
                    transform_label, transforms = self.build_transform(epsg_info, source_crs, zone=zone)
                    self.SUPPORTED_TRANSFORMS[transform_label] = transforms
            else:
                # Just process this one, no zones
                transform_label, transforms = self.build_transform(epsg_info, source_crs)
                self.SUPPORTED_TRANSFORMS[transform_label] = transforms

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        return QCoreApplication.translate('icsm_ntv2_transformer', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None
    ):
        self.dlg = icsm_ntv2_transformerDialog()
        self.update_transform_text("Choose an in file to get started.")

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/icsm_ntv2_transformer/icon.png'
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.add_action(
            icon_path,
            text=self.tr(u'ICSM NTv2 Transformer'),
            callback=self.run,
            parent=self.iface.mainWindow())

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&ICSM NTv2 Transformer'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar

    def run(self):
        """Run method that performs all the real work"""

        # Set up the signals.
        if not self.dialog_initialised:
            QObject.connect(self.dlg.in_file_browse, SIGNAL("clicked()"), self.browse_infiles)
            QObject.connect(self.dlg.in_file_name, SIGNAL("textChanged(QString)"), self.update_infile)
            QObject.connect(self.dlg.out_file_browse, SIGNAL("clicked()"), self.browse_outfiles)
            QObject.connect(self.dlg.out_crs_picker, SIGNAL("currentIndexChanged(int)"), self.transform_changed)
            self.dialog_initialised = True

        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()

        # TODO: Make this work
        help_pressed = False
        if help_pressed:
            help_file = 'Example'
            subprocess.Popen([help_file], shell=True)
            log("Not implemented.")

        # See if OK was pressed
        if result:
            log("Starting transform process...")
            self.in_file = self.dlg.in_file_name.text()
            self.out_file = self.dlg.out_file_name.text()

            if self.in_file_type:
                if not self.out_file:
                    log("No outfile set, writing to default name.")
                    filename, file_extension = os.path.splitext(self.in_file)
                    # Setting up default out file without an extension...
                    out_file = filename + '_transformed'
                    if self.in_file_type == 'VECTOR':
                        out_file += '.shp'
                    else:
                        out_file += '.tiff'
                    self.out_file = out_file
                    self.dlg.out_file_name.setText(self.out_file)

                if self.in_file_type == 'VECTOR':
                    self.transform_vector(self.out_file)
                else:
                    self.transform_raster(self.out_file)
            else:
                self.iface.messageBar().pushMessage(
                    "Error", "Invalid settings...", level=QgsMessageBar.CRITICAL, duration=3)
